<aside class="widget">
  <?php dynamic_sidebar('sidebar-right'); ?>
</aside>